//----------------------------------------------
//            Tasharen Network
// Copyright © 2012-2014 Tasharen Entertainment
//----------------------------------------------

// Note on the UDP lobby: Although it's a better choice than TCP (and plus it allows LAN broadcasts),
// it doesn't seem to work with the Amazon EC2 cloud-hosted servers. They don't seem to accept inbound UDP traffic
// without an active TPC connection from the same source... so it's your choice which protocol to use.

using System;
using TNet;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Net;

/// <summary>
/// This is an example of a stand-alone server. You don't need Unity in order to compile and run it.
/// Running it as-is will start a Game Server on ports 5127 (TCP) and 5128 (UDP), as well as a Lobby Server on port 5129.
/// </summary>

public class Application : IDisposable
{
	string mFilename;
	UPnP mUPnP = null;
	GameServer mGameServer = null;
	LobbyServer mLobbyServer = null;
	Thread mSaveThread = null;

	public delegate bool HandlerRoutine (int type);
	[System.Runtime.InteropServices.DllImport("Kernel32")]
	static extern bool SetConsoleCtrlHandler (HandlerRoutine Handler, bool Add);

	/// <summary>
	/// Function executed by kernel32 when the application exits. This is the only way to reliably detect a closed app in Windows.
	/// </summary>

	bool OnExit (int type) { Dispose(); return true; }

	/// <summary>
	/// Start the server.
	/// </summary>

	public void Start (string serverName, int tcpPort, int udpPort, string lobbyAddress, int lobbyPort, bool useTcp, bool service, string fn = "server.dat")
	{
		mFilename = fn;
		List<IPAddress> ips = Tools.localAddresses;
		string text = "\nLocal IPs: " + ips.size;

		for (int i = 0; i < ips.size; ++i)
		{
			text += "\n  " + (i + 1) + ": " + ips[i];
			if (ips[i] == TNet.Tools.localAddress) text += " (Primary)";
		}

		Console.WriteLine(text + "\n");
		{
			// Universal Plug & Play is used to determine the external IP address,
			// and to automatically open up ports on the router / gateway.
			mUPnP = new UPnP();
			mUPnP.WaitForThreads();

			if (mUPnP.status == UPnP.Status.Success)
			{
				Console.WriteLine("Gateway IP:  " + mUPnP.gatewayAddress);
			}
			else
			{
				Console.WriteLine("Gateway IP:  None found");
				mUPnP = null;
			}

			Console.WriteLine("External IP: " + Tools.externalAddress);
			Console.WriteLine("");

			if (tcpPort > 0)
			{
				mGameServer = new GameServer();
				mGameServer.name = serverName;

				if (!string.IsNullOrEmpty(lobbyAddress))
				{
					// Remote lobby address specified, so the lobby link should point to a remote location
					IPEndPoint ip = Tools.ResolveEndPoint(lobbyAddress, lobbyPort);
					if (useTcp) mGameServer.lobbyLink = new TcpLobbyServerLink(ip);
					else mGameServer.lobbyLink = new UdpLobbyServerLink(ip);

				}
				else if (lobbyPort > 0)
				{
					// Server lobby port should match the lobby port on the client
					if (useTcp)
					{
						mLobbyServer = new TcpLobbyServer();
						mLobbyServer.Start(lobbyPort);
						if (mUPnP != null) mUPnP.OpenTCP(lobbyPort, OnPortOpened);
					}
					else
					{
						mLobbyServer = new UdpLobbyServer();
						mLobbyServer.Start(lobbyPort);
						if (mUPnP != null) mUPnP.OpenUDP(lobbyPort, OnPortOpened);
					}

					// Local lobby server
					mGameServer.lobbyLink = new LobbyServerLink(mLobbyServer);
				}

				// Start the actual game server and load the save file
				mGameServer.Start(tcpPort, udpPort);
				mGameServer.LoadFrom(mFilename);
				Console.WriteLine("Loaded " + mFilename);
			}
			else if (lobbyPort > 0)
			{
				if (useTcp)
				{
					if (mUPnP != null) mUPnP.OpenTCP(lobbyPort, OnPortOpened);
					mLobbyServer = new TcpLobbyServer();
					mLobbyServer.Start(lobbyPort);
				}
				else
				{
					if (mUPnP != null) mUPnP.OpenUDP(lobbyPort, OnPortOpened);
					mLobbyServer = new UdpLobbyServer();
					mLobbyServer.Start(lobbyPort);
				}
			}

			// Open up ports on the router / gateway
			if (mUPnP != null)
			{
				if (tcpPort > 0) mUPnP.OpenTCP(tcpPort, OnPortOpened);
				if (udpPort > 0) mUPnP.OpenUDP(udpPort, OnPortOpened);
			}

			// This approach doesn't work on Windows 7 and higher.
			AppDomain.CurrentDomain.ProcessExit += new EventHandler(delegate(object sender, EventArgs e) { Dispose(); });

			// This approach works only on Windows
			try { SetConsoleCtrlHandler(new HandlerRoutine(OnExit), true); }
			catch (Exception) { }

			// Save periodically
			mSaveThread = new Thread(delegate(object obj)
			{
				for (; ; )
				{
					Thread.Sleep(120000);
					if (mGameServer != null) mGameServer.SaveTo(mFilename);
				}
			});
			mSaveThread.Start();

			for (; ; )
			{
				if (!service)
				{
					Console.WriteLine("Press 'q' followed by ENTER when you want to quit.\n");
					string command = Console.ReadLine();
					if (command == "q") break;
					if (command == "s")
					{
						mGameServer.SaveTo(mFilename);
						Console.WriteLine("Saved as " + mFilename);
					}
				}
				else Thread.Sleep(10000);
			}
			Console.WriteLine("Shutting down...");
			Dispose();
		}

		if (!service)
		{
			Console.WriteLine("The server has shut down. Press ENTER to terminate the application.");
			Console.ReadLine();
		}
	}

	/// <summary>
	/// Stop the server.
	/// </summary>

	public void Dispose ()
	{
		if (mSaveThread != null)
		{
			mSaveThread.Abort();
			mSaveThread = null;
		}

		// Stop the game server
		if (mGameServer != null)
		{
			Console.WriteLine("Saved as " + mFilename);
			mGameServer.SaveTo(mFilename);
			mGameServer.Stop();
			mGameServer = null;
		}

		// Stop the lobby server
		if (mLobbyServer != null)
		{
			mLobbyServer.Stop();
			mLobbyServer = null;
		}

		// Close all opened ports
		if (mUPnP != null)
		{
			mUPnP.Close();
			mUPnP.WaitForThreads();
			mUPnP = null;
		}
	}

	/// <summary>
	/// UPnP notification of a port being open.
	/// </summary>

	void OnPortOpened (UPnP up, int port, ProtocolType protocol, bool success)
	{
		if (success)
		{
			Console.WriteLine("UPnP: " + protocol.ToString().ToUpper() + " port " + port + " was opened successfully.");
		}
		else
		{
			Console.WriteLine("UPnP: Unable to open " + protocol.ToString().ToUpper() + " port " + port);
		}
	}

	/// <summary>
	/// Application entry point -- parse the parameters.
	/// </summary>

	static int Main (string[] args)
	{
		if (args == null || args.Length == 0)
		{
			Console.WriteLine("No arguments specified, assuming default values.");
			Console.WriteLine("In the future you can specify arguments like these:\n");
			Console.WriteLine("   -name \"Your Server\"      <-- Name your server");
			Console.WriteLine("   -world \"Your World\"      <-- World to choose");
			Console.WriteLine("   -tcp [port]              <-- TCP port for clients to connect to");
			Console.WriteLine("   -public                  <-- Make the server public");
			Console.WriteLine("   -service                 <-- Run it as a service");
			Console.WriteLine("\nFor example:");
			Console.WriteLine("  WWServer -name \"My Server\" -tcp 5127 -public");

			args = new string[] { "-name", "Windward Server", "-tcp", "5127", "-world", "World" };
		}

		string serverName = "Windward Server";
		string worldName = "World";
		int tcpPort = 0;
		int udpPort = 0;
		string lobbyAddress = null;
		int lobbyPort = 0;
		bool tcpLobby = false;
		bool service = false;

		for (int i = 0; i < args.Length; )
		{
			string param = args[i];
			string val0 = (i + 1 < args.Length) ? args[i + 1] : null;
			string val1 = (i + 2 < args.Length) ? args[i + 2] : null;

			if (val0 != null && val0.StartsWith("-"))
			{
				val0 = null;
				val1 = null;
			}
			else if (val1 != null && val1.StartsWith("-"))
			{
				val1 = null;
			}

			if (param == "-name")
			{
				if (val0 != null) serverName = val0;
			}
			else if (param == "-world")
			{
				if (val0 != null) worldName = val0;
			}
			else if (param == "-tcp")
			{
				if (val0 != null) int.TryParse(val0, out tcpPort);
			}
			else if (param == "-udp")
			{
				if (val0 != null) int.TryParse(val0, out udpPort);
			}
			else if (param == "-ip")
			{
				if (val0 != null) UdpProtocol.defaultNetworkInterface = Tools.ResolveAddress(val0);
			}
			else if (param == "-tcpLobby")
			{
				if (val1 != null)
				{
					lobbyAddress = val0;
					int.TryParse(val1, out lobbyPort);
				}
				else int.TryParse(val0, out lobbyPort);
				tcpLobby = true;
			}
			else if (param == "-udpLobby")
			{
				if (val1 != null)
				{
					lobbyAddress = val0;
					int.TryParse(val1, out lobbyPort);
				}
				else int.TryParse(val0, out lobbyPort);
				tcpLobby = false;
			}
			else if (param == "-lobby")
			{
				if (val0 != null) lobbyAddress = val0;
			}
			else if (param == "-public")
			{
				lobbyAddress = "server.tasharen.com";
				lobbyPort = 5190;
				tcpLobby = true;
			}
			else if (param == "-service")
			{
				service = true;
			}

			if (val1 != null) i += 3;
			else if (val0 != null) i += 2;
			else ++i;
		}

		if (string.IsNullOrEmpty(worldName)) worldName = "World";
		worldName = Tools.GetDocumentsPath("Windward/Worlds/" + worldName + ".dat");
		Application app = new Application();
		app.Start(serverName, tcpPort, udpPort, lobbyAddress, lobbyPort, tcpLobby, service, worldName);
		return 0;
	}
}
